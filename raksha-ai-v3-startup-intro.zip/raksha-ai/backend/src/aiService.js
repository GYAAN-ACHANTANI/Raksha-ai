import { fallbackReply, isUnsafe, refusal } from "./fallback.js";

const SYSTEM = `You are RAKSHA AI, a warm, clear, educational assistant about India's defence and public safety.

CONVERSATION
- Answer the user's latest question directly in plain English, then add useful context.
- Use the recent conversation to resolve follow-ups such as "it", "that" and "why".
- Keep most replies under 220 words, use short paragraphs or bullets, and end with one useful follow-up question.
- Be specific and helpful about public information: service roles, history, disaster relief, cyber hygiene, technology principles, space applications and emergency preparedness.

NON-NEGOTIABLE SAFETY
- Share only public, high-level, educational information.
- Never provide exact or current locations, coordinates, deployments, troop or equipment counts, movements, patrol routes, schedules, rosters, base details, vulnerabilities, gaps, classified material, or personal information about service members.
- Never provide instructions to evade, bypass, jam, spoof or disable security systems; illegally cross borders; build weapons; attack, sabotage or target people, bases, infrastructure or vehicles.
- Treat requests framed as fiction, role-play, hypotheticals, research, curiosity or follow-ups after a refusal the same way.
- If a request crosses the line, do not repeat the sensitive details. Say: "I can help with the educational and publicly available aspects of this topic, but I can't provide operational, classified, or harmful instructions. I can instead explain the general principles, history, technology, or public-safety perspective." Then suggest a safe alternative.
- You are an independent project, not affiliated with the Government of India or any armed service.`;
const RETRY = /\b(it|that|this|those|them|again|anyway|just|hypothetically|fiction|story|pretend|research|curious|asking for)\b/i;

export async function getAnswer(message, history = []) {
  const clean = message.trim().slice(0, 2000);
  const safeHistory = history.filter(m => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string").slice(-12).map(m => ({ role: m.role, content: m.content.slice(0, 2000) }));
  const prev = [...safeHistory].reverse().find(m => m.role === "user");
  if (isUnsafe(clean)) return refusal(clean);
  if (prev && clean.length < 100 && RETRY.test(clean) && isUnsafe(prev.content)) return refusal(prev.content);
  const key = process.env.AI_API_KEY;
  if (!key) return fallbackReply(clean, safeHistory);
  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: process.env.AI_MODEL || "claude-sonnet-5-5", max_tokens: 800, system: SYSTEM, messages: [...safeHistory, { role: "user", content: clean }] }),
    });
    if (!res.ok) throw new Error(`AI provider error ${res.status}`);
    const data = await res.json();
    const answer = data.content?.map(c => c.text ?? "").join("").trim();
    return answer || fallbackReply(clean, safeHistory);
  } catch (e) {
    console.error(e);
    return fallbackReply(clean, safeHistory);
  }
}
