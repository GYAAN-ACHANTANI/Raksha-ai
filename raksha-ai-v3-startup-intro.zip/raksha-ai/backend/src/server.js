import "dotenv/config";
import express from "express";
import cors from "cors";
import { getAnswer } from "./aiService.js";

const app = express();
app.use(cors({ origin: process.env.CLIENT_URL || true }));
app.use(express.json({ limit: "1mb" }));
app.get("/api/health", (_req, res) => res.json({ status: "ok", service: "raksha-ai", mode: process.env.AI_API_KEY ? "live-model-with-fallback" : "built-in-knowledge-engine", time: new Date().toISOString() }));
const valid = body => typeof body?.message === "string" && body.message.trim().length > 0;
app.post("/api/chat", async (req, res) => {
  if (!valid(req.body)) return res.status(400).json({ error: "Message required" });
  res.json({ reply: await getAnswer(req.body.message, Array.isArray(req.body.history) ? req.body.history : []) });
});
app.post("/api/chat/stream", async (req, res) => {
  if (!valid(req.body)) return res.status(400).end();
  res.set({ "Content-Type": "text/event-stream; charset=utf-8", "Cache-Control": "no-cache, no-transform", Connection: "keep-alive", "X-Accel-Buffering": "no" });
  res.flushHeaders?.();
  const reply = await getAnswer(req.body.message, Array.isArray(req.body.history) ? req.body.history : []);
  let closed = false;
  req.on("close", () => { closed = true; });
  for (const part of reply.match(/\S+\s*|\n/g) ?? []) {
    if (closed) return;
    res.write(`data: ${JSON.stringify({ t: part })}\n\n`);
    await new Promise(r => setTimeout(r, 22));
  }
  if (!closed) { res.write("data: [DONE]\n\n"); res.end(); }
});
const port = Number(process.env.PORT) || 5000;
app.listen(port, () => console.log(`RAKSHA backend running on http://localhost:${port}`));
