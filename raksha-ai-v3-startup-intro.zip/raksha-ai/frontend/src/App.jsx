import { useEffect, useState } from "react";
import { LogOut, Menu, Plus, Trash2, Pencil, Star, Search } from "lucide-react";
import Intro from "./Intro";
import Login from "./Login";
import Chat from "./Chat";
const MODULES = [
    ["Indian Army", "Give me an overview of the Indian Army."], ["Indian Navy", "Give me an overview of the Indian Navy."],
    ["Indian Air Force", "Give me an overview of the Indian Air Force."], ["Border Security", "How does border management work in India?"],
    ["National Security", "What are the major components of national security?"], ["Cyber Defence", "What is cyber defence?"],
    ["Defence Technology", "What are India's major defence technologies?"], ["Space & Security", "How do satellites support national security?"],
    ["Emergency Preparedness", "How should a family prepare for disasters?"],
];
const load = (k, d) => { try {
    return JSON.parse(localStorage.getItem(k) || "");
}
catch {
    return d;
} };
const fresh = () => ({ id: crypto.randomUUID(), title: "New conversation", date: new Date().toISOString(), messages: [] });
export default function App() {
    // Always run the complete onboarding sequence on startup. Previously a saved
    // localStorage user sent returning visitors straight to the chat screen.
    const [stage, setStage] = useState("intro");
    const [user, setUser] = useState(localStorage.getItem("raksha_user") || "");
    const [convs, setConvs] = useState(() => { const c = load("raksha_convs", []); return c.length ? c : [fresh()]; });
    const [active, setActive] = useState(convs[0].id);
    const [open, setOpen] = useState(false);
    const [q, setQ] = useState("");
    useEffect(() => { localStorage.setItem("raksha_convs", JSON.stringify(convs)); }, [convs]);
    if (stage === "intro")
        return <Intro onDone={() => setStage("login")}/>;
    if (stage === "login")
        return <Login onLogin={n => { localStorage.setItem("raksha_user", n); setUser(n); setStage("app"); }}/>;
    const conv = convs.find(c => c.id === active) ?? convs[0];
    const update = (c) => setConvs(cs => cs.map(x => (x.id === c.id ? c : x)));
    const create = (title) => { const c = fresh(); if (title)
        c.title = title; setConvs(cs => [c, ...cs]); setActive(c.id); setOpen(false); };
    const remove = (id) => { const rest = convs.filter(c => c.id !== id); const next = rest.length ? rest : [fresh()]; setConvs(next); setActive(next[0].id); };
    const rename = (c) => { const t = prompt("Rename conversation", c.title); if (t?.trim())
        update({ ...c, title: t.trim() }); };
    const exportAll = () => { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([JSON.stringify(convs, null, 2)])); a.download = "raksha-conversations.json"; a.click(); };
    const logout = () => { localStorage.removeItem("raksha_user"); setStage("intro"); };
    return (<div className="h-screen flex">
      <aside className={`fixed md:static z-20 inset-y-0 left-0 w-72 bg-panel border-r border-slate-800 flex flex-col transition-transform ${open ? "" : "-translate-x-full md:translate-x-0"}`}>
        <div className="p-4 font-semibold tracking-[.25em]">RAKSHA <span className="text-cyan2">AI</span></div>
        <button onClick={() => create()} className="mx-3 mb-2 flex items-center gap-2 px-3 py-2 rounded bg-cyan2 text-navy text-sm font-semibold"><Plus size={16}/>New conversation</button>
        <div className="mx-3 mb-2 flex items-center gap-2 bg-navy border border-slate-700 rounded px-2"><Search size={14} className="text-slate-500"/>
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search conversations" className="bg-transparent py-1.5 text-sm outline-none flex-1"/></div>
        <div className="flex-1 overflow-y-auto px-3 space-y-1">
          <div className="text-xs text-slate-500 mt-2 mb-1">Explore modules</div>
          {MODULES.map(([n, p]) => <button key={n} onClick={() => { const c = fresh(); c.title = n; setConvs(cs => [c, ...cs]); setActive(c.id); setOpen(false); sessionStorage.setItem("raksha_auto", p); }} className="w-full text-left text-sm px-2 py-1 rounded hover:bg-slate-800">{n}</button>)}
          <div className="text-xs text-slate-500 mt-3 mb-1">Chat history</div>
          {convs.filter(c => c.title.toLowerCase().includes(q.toLowerCase())).map(c => (<div key={c.id} className={`group flex items-center gap-1 px-2 py-1 rounded text-sm cursor-pointer ${c.id === conv.id ? "bg-slate-800" : "hover:bg-slate-800/60"}`} onClick={() => { setActive(c.id); setOpen(false); }}>
              <span className="flex-1 truncate">{c.title}</span>
              <Pencil size={13} className="opacity-0 group-hover:opacity-100" onClick={e => { e.stopPropagation(); rename(c); }}/>
              <Trash2 size={13} className="opacity-0 group-hover:opacity-100 text-saffron" onClick={e => { e.stopPropagation(); remove(c.id); }}/>
            </div>))}
        </div>
        <div className="p-3 border-t border-slate-800 text-xs text-slate-400 space-y-2">
          <div className="flex items-center gap-2"><Star size={12}/>Your conversations are saved on this device.</div>
          <div className="flex justify-between items-center"><span>{user}</span>
            <span className="flex gap-3"><button onClick={exportAll} className="hover:text-white">Export</button>
              <button onClick={() => { if (confirm("Clear all chat history?")) {
        const c = fresh();
        setConvs([c]);
        setActive(c.id);
    } }} className="hover:text-white">Clear</button>
              <button onClick={logout} title="Logout"><LogOut size={14}/></button></span></div>
          <p className="text-[10px] leading-snug text-slate-500">Independent educational project, not affiliated with the Government of India or any armed service. Information is for educational and public-awareness purposes.</p>
        </div>
      </aside>
      <main className="flex-1 min-w-0 relative">
        <button className="md:hidden absolute top-4 right-3 z-10 p-1" onClick={() => setOpen(!open)}><Menu /></button>
        <Chat key={conv.id} conv={conv} onChange={update}/>
      </main>
    </div>);
}
