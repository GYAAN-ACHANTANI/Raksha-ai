import { useState } from "react";
import { motion } from "framer-motion";
import Orb from "./Orb";
export default function Login({ onLogin }) {
    const [u, setU] = useState("");
    const [p, setP] = useState("");
    const [err, setErr] = useState("");
    const [boot, setBoot] = useState(-1);
    const steps = ["AUTHENTICATING", "INITIALIZING RAKSHA AI", "AI CORE ONLINE", "ACCESS GRANTED"];
    const run = (name) => {
        steps.forEach((_, i) => setTimeout(() => setBoot(i), i * 800));
        setTimeout(() => setBoot(4), steps.length * 800);
        setTimeout(() => onLogin(name), steps.length * 800 + 1200);
    };
    const submit = (e) => {
        e.preventDefault();
        if (!u.trim() || p.length < 4)
            return setErr("Enter your user ID and a password of at least 4 characters.");
        run(u.trim());
    };
    if (boot >= 0)
        return (<div className="min-h-screen flex flex-col items-center justify-center gap-6">
      <Orb state="thinking" size={110}/>
      <motion.div key={boot} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="tracking-[.3em] text-cyan2">
        {boot < 4 ? steps[boot] : `WELCOME, ${(u || "GUEST").toUpperCase()}`}
      </motion.div>
    </div>);
    return (<div className="min-h-screen flex items-center justify-center p-4">
      <motion.form onSubmit={submit} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-sm bg-panel/80 backdrop-blur border border-cyan2/20 rounded-lg p-8 space-y-4">
        <div className="flex justify-center"><Orb state="idle" size={72}/></div>
        <h1 className="text-center text-2xl font-semibold tracking-[.3em]">LOGIN</h1>
        <input value={u} onChange={e => setU(e.target.value)} placeholder="User ID / Username" className="w-full bg-navy border border-slate-700 rounded px-3 py-2 outline-none focus:border-cyan2"/>
        <input type="password" value={p} onChange={e => setP(e.target.value)} placeholder="Password" className="w-full bg-navy border border-slate-700 rounded px-3 py-2 outline-none focus:border-cyan2"/>
        {err && <div className="text-saffron text-sm">{err}</div>}
        <button className="w-full py-2 rounded bg-cyan2 text-navy font-semibold tracking-widest hover:brightness-110">LOGIN</button>
        <button type="button" onClick={() => { setU("Guest"); run("Guest"); }} className="w-full text-sm text-slate-400 hover:text-white">Continue as Guest</button>
        <p className="text-[11px] text-slate-500 text-center pt-2">RAKSHA AI is an independent educational technology project. It is not affiliated with, endorsed by, or operated by the Government of India, Ministry of Defence, Indian Army, Indian Navy, or Indian Air Force.</p>
      </motion.form>
    </div>);
}
