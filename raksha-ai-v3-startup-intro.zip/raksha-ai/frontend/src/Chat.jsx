import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { CheckCircle2, Copy, LockKeyhole, Mic, RefreshCw, Send, ShieldAlert, Square, Volume2, ThumbsDown, ThumbsUp, Wifi, WifiOff } from "lucide-react";
import Orb from "./Orb";

const SUGGEST = [
  ["Indian Army", "Explain the Indian Army's role in disaster response."],
  ["Indian Navy", "How does the Indian Navy support maritime safety?"],
  ["Indian Air Force", "How does the Indian Air Force help during emergencies?"],
  ["Border Security", "Explain border management at a high level."],
  ["Defence Technology", "How is AI used responsibly in defence?"],
  ["Cyber Safety", "Give me practical tips to protect my phone from phishing."],
  ["Space", "How do satellites help during floods and cyclones?"],
  ["Preparedness", "What should a family keep in an emergency kit?"],
];
const LOCAL_SENSITIVE = /\b(exact|current|secret|classified|confidential|coordinates?|gps|location|where (are|is)|troop numbers?|strength|deployment|movement|route|schedule|weak point|vulnerab|bypass|evade|jam|spoof|attack|sabotage|target)\b/i;

export default function Chat({ conv, onChange }) {
  const [input, setInput] = useState("");
  const [orb, setOrb] = useState("idle");
  const [busy, setBusy] = useState(false);
  const [listening, setListening] = useState(false);
  const [note, setNote] = useState("");
  const [online, setOnline] = useState(null);
  const abort = useRef(null);
  const end = useRef(null);
  const msgs = conv.messages;

  useEffect(() => {
    const p = sessionStorage.getItem("raksha_auto");
    if (p && msgs.length === 0) { sessionStorage.removeItem("raksha_auto"); ask(p, []); }
  }, []);
  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs]);
  useEffect(() => {
    let alive = true;
    const check = () => fetch("/api/health", { signal: AbortSignal.timeout(3500) }).then(r => { if (alive) setOnline(r.ok); }).catch(() => { if (alive) setOnline(false); });
    check(); const id = setInterval(check, 15000); return () => { alive = false; clearInterval(id); };
  }, []);

  async function ask(text, base) {
    const history = base.map(({ role, content }) => ({ role, content }));
    let cur = [...base, { role: "user", content: text }, { role: "assistant", content: "" }];
    const title = base.length === 0 ? text.slice(0, 40) : conv.title;
    onChange({ ...conv, title, messages: cur });
    setBusy(true); setOrb("thinking"); setNote("");
    abort.current = new AbortController();
    try {
      const res = await fetch("/api/chat/stream", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: text, history }), signal: abort.current.signal });
      if (!res.ok || !res.body) throw new Error("bad response");
      setOnline(true);
      const reader = res.body.getReader(); const dec = new TextDecoder(); let buf = ""; let out = ""; setOrb("responding");
      for (;;) {
        const { done, value } = await reader.read(); if (done) break;
        buf += dec.decode(value, { stream: true }); const lines = buf.split("\n\n"); buf = lines.pop() ?? "";
        for (const line of lines) { const d = line.replace(/^data: /, ""); if (!d || d === "[DONE]") continue; out += JSON.parse(d).t; cur = [...cur.slice(0, -1), { role: "assistant", content: out }]; onChange({ ...conv, title, messages: cur }); }
      }
      setOrb("idle");
    } catch (e) {
      if (e.name !== "AbortError") { setOnline(false); setOrb("error"); setNote("RAKSHA AI could not reach the local response service. Start the backend with npm run dev, then try again."); setTimeout(() => setOrb("idle"), 3000); } else setOrb("idle");
    } finally { setBusy(false); }
  }
  const send = (t = input) => {
    const v = t.trim(); if (!v || busy) return;
    if (LOCAL_SENSITIVE.test(v)) setNote("Safety screen active: operational or sensitive military details are not shared. I can help with public, high-level information instead.");
    setInput(""); ask(v, msgs);
  };
  const regen = () => { const i = msgs.map(m => m.role).lastIndexOf("user"); if (i >= 0 && !busy) ask(msgs[i].content, msgs.slice(0, i)); };
  const mic = () => { const SR = window.SpeechRecognition || window.webkitSpeechRecognition; if (!SR) return setNote("Voice input isn't supported in this browser. Try Chrome or Edge."); const r = new SR(); r.lang = "en-IN"; setListening(true); setOrb("listening"); r.onresult = e => setInput(e.results[0][0].transcript); r.onend = () => { setListening(false); setOrb("idle"); }; r.start(); };
  const speak = t => { speechSynthesis.cancel(); speechSynthesis.speak(new SpeechSynthesisUtterance(t.replace(/[*#]/g, ""))); };
  const react = (i, v) => onChange({ ...conv, messages: msgs.map((m, j) => j === i ? { ...m, liked: m.liked === v ? null : v } : m) });
  return <div className="flex flex-col h-full">
    <header className="flex items-center gap-3 px-4 py-3 border-b border-slate-800 bg-navy/40">
      <Orb state={orb} size={44}/><div className="min-w-0"><h2 className="font-semibold tracking-widest">RAKSHA AI</h2><p className="text-xs text-slate-400">India's Defence &amp; National Security AI Assistant</p></div>
      <div className="ml-auto flex items-center gap-2 text-[10px] tracking-widest" title={online ? "Backend connected" : online === false ? "Backend unavailable" : "Checking connection"}>{online ? <><Wifi size={14} className="text-india"/><span className="hidden sm:inline text-india">LIVE</span></> : online === false ? <><WifiOff size={14} className="text-saffron"/><span className="hidden sm:inline text-saffron">OFFLINE</span></> : <span className="text-slate-500">CHECKING</span>}</div>
    </header>
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {msgs.length === 0 && <div className="max-w-3xl mx-auto text-center pt-6"><div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-cyan2/20 bg-cyan2/5 text-[10px] tracking-widest text-cyan2 mb-5"><LockKeyhole size={12}/> PUBLIC KNOWLEDGE MODE</div><h1 className="text-3xl font-semibold mb-2">Welcome to RAKSHA AI</h1><p className="text-slate-400 mb-6">Ask naturally. Get a live, educational answer about defence, security, technology and preparedness.</p><div className="grid sm:grid-cols-2 gap-3 text-left">{SUGGEST.map(([t, q]) => <button key={t} onClick={() => send(q)} className="p-3 rounded-lg bg-panel border border-slate-800 hover:border-cyan2/60 hover:-translate-y-0.5 transition"><div className="text-xs text-saffron">{t}</div><div className="text-sm">{q}</div></button>)}</div></div>}
      {msgs.map((m, i) => <motion.div key={i} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className={`max-w-3xl mx-auto flex ${m.role === "user" ? "justify-end" : ""}`}><div className={`rounded-lg px-4 py-3 whitespace-pre-wrap text-sm leading-relaxed max-w-[90%] ${m.role === "user" ? "bg-cyan2/15 border border-cyan2/30" : "bg-panel border border-slate-800"}`}>{m.content || <span className="text-cyan2 animate-pulse">Thinking…</span>}{m.role === "assistant" && m.content && !busy && <div className="flex gap-3 mt-3 text-slate-500"><Copy size={15} className="cursor-pointer hover:text-white" onClick={() => navigator.clipboard.writeText(m.content)}/><Volume2 size={15} className="cursor-pointer hover:text-white" onClick={() => speak(m.content)}/><Square size={15} className="cursor-pointer hover:text-white" onClick={() => speechSynthesis.cancel()}/>{i === msgs.length - 1 && <RefreshCw size={15} className="cursor-pointer hover:text-white" onClick={regen}/>}<ThumbsUp size={15} className={`cursor-pointer ${m.liked === true ? "text-india" : "hover:text-white"}`} onClick={() => react(i, true)}/><ThumbsDown size={15} className={`cursor-pointer ${m.liked === false ? "text-saffron" : "hover:text-white"}`} onClick={() => react(i, false)}/></div>}</div></motion.div>)}
      <div ref={end}/>
    </div>
    <div className="p-3 border-t border-slate-800"><div className="max-w-3xl mx-auto flex items-center gap-2 text-[10px] text-slate-500 mb-2"><ShieldAlert size={13} className="text-saffron"/> Safety filter blocks operational, classified and harmful military details. <CheckCircle2 size={13} className="text-india ml-auto"/> Educational mode</div>{note && <div className="max-w-3xl mx-auto text-xs text-saffron mb-2">{note}</div>}<div className="max-w-3xl mx-auto flex items-end gap-2 bg-panel border border-slate-700 rounded-xl p-2 focus-within:border-cyan2"><textarea rows={1} value={listening ? "LISTENING..." : input} maxLength={1000} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }} onInput={e => { const t = e.currentTarget; t.style.height = "auto"; t.style.height = Math.min(t.scrollHeight, 160) + "px"; }} placeholder="Ask RAKSHA AI about India's defence, security, technology or preparedness..." className="flex-1 bg-transparent resize-none outline-none px-2 py-1 text-sm"/><span className="text-[10px] text-slate-500 self-center">{input.length}/1000</span><button onClick={mic} className={`p-2 rounded ${listening ? "text-saffron animate-pulse" : "text-slate-400 hover:text-white"}`}><Mic size={18}/></button>{busy ? <button onClick={() => abort.current?.abort()} className="p-2 rounded bg-saffron text-navy"><Square size={18}/></button> : <button onClick={() => send()} className="p-2 rounded bg-cyan2 text-navy"><Send size={18}/></button>}</div></div>
  </div>;
}
