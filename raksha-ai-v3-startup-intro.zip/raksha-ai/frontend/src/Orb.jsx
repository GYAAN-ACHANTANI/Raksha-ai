import { motion } from "framer-motion";
const speed = { idle: 24, listening: 14, thinking: 4, responding: 10, error: 30 };
export default function Orb({ state, size = 64 }) {
    const c = state === "error" ? "#ff9933" : "#3ec6e0";
    return (<div style={{ width: size, height: size }} className="relative shrink-0" title={state.toUpperCase()}>
      {[0, 1].map(i => (<motion.div key={i} className="absolute inset-0 rounded-full border border-dashed" style={{ borderColor: c, inset: i * size * 0.14 }} animate={{ rotate: i ? -360 : 360 }} transition={{ repeat: Infinity, ease: "linear", duration: speed[state] / (i + 1) }}/>))}
      <motion.div className="absolute rounded-full" style={{ inset: size * 0.32, background: `radial-gradient(${c}, #0a3a5a)`, boxShadow: `0 0 18px ${c}` }} animate={{ scale: state === "responding" ? [1, 1.25, 1] : [1, 1.08, 1] }} transition={{ repeat: Infinity, duration: state === "responding" ? 0.8 : 2.5 }}/>
    </div>);
}
