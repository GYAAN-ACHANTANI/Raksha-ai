import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

const SERVICES = [
  { name: "INDIAN ARMY", label: "LAND", color: "#43d17d", icon: "◈", copy: "Land operations, engineering, medical support and disaster relief.", Scene: ArmyScene },
  { name: "INDIAN NAVY", label: "SEA", color: "#3ec6e0", icon: "≈", copy: "Maritime safety, search and rescue, and protection of India's sea interests.", Scene: NavyScene },
  { name: "INDIAN AIR FORCE", label: "AIR", color: "#8ab4ff", icon: "✦", copy: "Air defence, transport, helicopters and rapid humanitarian response.", Scene: AirScene },
];

function Flag() {
  const strips = useMemo(() => Array.from({ length: 18 }, (_, i) => i), []);
  return <motion.div initial={{ opacity: 0, y: 22, scale: .88 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: 1 }} className="relative" style={{ width: 330, height: 235, filter: "drop-shadow(0 0 36px rgba(255,153,51,.38))" }}>
    <svg width="330" height="235" viewBox="0 0 330 235" role="img" aria-label="Waving Indian flag">
      <defs>
        <linearGradient id="clothShade" x1="0" x2="1"><stop stopColor="#fff" stopOpacity=".2"/><stop offset=".45" stopColor="#000" stopOpacity=".1"/><stop offset="1" stopColor="#fff" stopOpacity=".22"/></linearGradient>
        <clipPath id="clothClip"><path d="M48 34 C106 12 157 58 213 34 S278 18 311 38 V190 C255 168 205 207 147 184 S83 169 48 190Z" /></clipPath>
      </defs>
      <motion.path d="M31 22V212" stroke="#d2dbe8" strokeWidth="5" strokeLinecap="round" initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: .8 }} />
      <circle cx="31" cy="17" r="7" fill="#ffb347" />
      <g clipPath="url(#clothClip)">
        <rect x="46" y="20" width="275" height="57" fill="#ff9933"/><rect x="46" y="77" width="275" height="53" fill="#fff"/><rect x="46" y="130" width="275" height="65" fill="#138808"/>
        <g transform="translate(178 104)"><circle r="22" fill="none" stroke="#000080" strokeWidth="2"/>{Array.from({ length: 24 }).map((_, i) => <line key={i} x1="0" y1="0" x2={22 * Math.cos(i * Math.PI / 12)} y2={22 * Math.sin(i * Math.PI / 12)} stroke="#000080" strokeWidth="1"/>)}</g>
        <rect x="46" y="20" width="275" height="175" fill="url(#clothShade)"/>
        {strips.map(i => <motion.rect key={i} x={46 + i * 16} y="8" width="20" height="195" fill="#fff" opacity=".1" animate={{ skewX: [-10, 10, -10], x: [0, 6, 0] }} transition={{ repeat: Infinity, duration: 1.8 + i * .06, delay: i * .04, ease: "easeInOut" }} />)}
      </g>
      <path d="M48 34 C106 12 157 58 213 34 S278 18 311 38" fill="none" stroke="#fff" strokeOpacity=".25" strokeWidth="2"/><path d="M48 190 C83 169 111 207 147 184 S205 168 255 190" fill="none" stroke="#07111f" strokeOpacity=".35" strokeWidth="2"/>
    </svg>
  </motion.div>;
}

function SceneFrame({ children, color }) { return <div className="relative mx-auto mb-6 h-40 w-[min(90vw,560px)] overflow-hidden rounded-2xl border" style={{ borderColor: `${color}55`, background: `linear-gradient(180deg, ${color}12, #06101d 70%)`, boxShadow: `0 0 45px ${color}18` }}>{children}</div>; }
function ArmyScene() { return <SceneFrame color="#43d17d"><div className="absolute inset-x-0 bottom-0 h-14 bg-gradient-to-t from-[#123624] to-transparent"/><motion.div className="absolute bottom-8 left-[18%] text-6xl text-[#43d17d]" animate={{ y: [0, -4, 0] }} transition={{ repeat: Infinity, duration: 2 }}>◈</motion.div><motion.div className="absolute bottom-4 left-[47%] h-1 w-32 bg-[#43d17d]" animate={{ scaleX: [1, .7, 1] }} transition={{ repeat: Infinity, duration: 2.4 }}/><div className="absolute bottom-10 right-[18%] h-16 w-16 rotate-45 rounded-lg border-2 border-[#43d17d]"/><motion.div className="absolute top-8 left-8 h-1 w-16 bg-[#43d17d]" animate={{ x: [0, 90, 220], opacity: [0, 1, 0] }} transition={{ repeat: Infinity, duration: 3 }}/><div className="absolute bottom-2 left-4 text-[9px] tracking-[.35em] text-[#43d17d]">GROUND // SUPPORT // RESILIENCE</div></SceneFrame>; }
function NavyScene() { return <SceneFrame color="#3ec6e0"><div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_25%,rgba(62,198,224,.22),transparent_32%)]"/><motion.div className="absolute bottom-11 left-[38%] text-5xl text-[#3ec6e0]" animate={{ y: [0, -3, 0], x: [-10, 10, -10] }} transition={{ repeat: Infinity, duration: 2.8 }}>▰</motion.div><div className="absolute bottom-9 left-[30%] h-1 w-48 bg-[#3ec6e0]"/><div className="absolute bottom-5 left-0 right-0 flex gap-5 text-3xl text-[#3ec6e0] opacity-70"><motion.span animate={{ x: [-15, 15, -15] }} transition={{ repeat: Infinity, duration: 2 }}>≈ ≈ ≈ ≈ ≈ ≈</motion.span></div><motion.div className="absolute top-9 left-10 h-1 w-20 bg-white/70" animate={{ x: [0, 350], opacity: [0, 1, 0] }} transition={{ repeat: Infinity, duration: 3.2 }}/><div className="absolute bottom-2 left-4 text-[9px] tracking-[.35em] text-[#3ec6e0]">MARITIME // RESCUE // SAFETY</div></SceneFrame>; }
function AirScene() { return <SceneFrame color="#8ab4ff"><motion.div className="absolute top-9 left-[-80px] text-5xl text-[#8ab4ff]" animate={{ x: [0, 650] }} transition={{ repeat: Infinity, duration: 3.5, ease: "linear" }}>✦</motion.div><motion.div className="absolute top-16 left-20 h-5 w-28 rounded-full bg-white/15" animate={{ x: [0, 80, 0] }} transition={{ repeat: Infinity, duration: 4 }}/><motion.div className="absolute top-28 right-20 h-4 w-20 rounded-full bg-white/10" animate={{ x: [0, -70, 0] }} transition={{ repeat: Infinity, duration: 3 }}/><div className="absolute inset-x-0 bottom-0 h-12 bg-gradient-to-t from-[#172d59] to-transparent"/><div className="absolute bottom-2 left-4 text-[9px] tracking-[.35em] text-[#8ab4ff]">AIRSPACE // MOBILITY // RELIEF</div></SceneFrame>; }

export default function Intro({ onDone }) {
  const [step, setStep] = useState(1);
  const [service, setService] = useState(0);
  useEffect(() => { const timers = [4200, 6800, 9800, 15000, 18800].map((t, i) => setTimeout(() => i === 4 ? onDone() : setStep(i + 2), t)); return () => timers.forEach(clearTimeout); }, [onDone]);
  useEffect(() => { if (step !== 4) return; const id = setInterval(() => setService(v => (v + 1) % SERVICES.length), 2300); return () => clearInterval(id); }, [step]);
  const Fade = ({ k, children }) => <motion.div key={k} initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -18 }} transition={{ duration: .65 }} className="text-center px-4">{children}</motion.div>;
  const active = SERVICES[service]; const ActiveScene = active.Scene;
  return <div className="fixed inset-0 z-50 flex items-center justify-center overflow-hidden bg-[#02060d]">
    <motion.div className="absolute h-[760px] w-[760px] rounded-full blur-3xl" style={{ background: "conic-gradient(#ff9933,#fff,#138808,#3ec6e0,#ff9933)" }} animate={{ opacity: [.08, .17, .08], rotate: 360 }} transition={{ opacity: { repeat: Infinity, duration: 5 }, rotate: { repeat: Infinity, duration: 32, ease: "linear" } }} />
    <div className="absolute left-8 top-8 text-[10px] tracking-[.35em] text-slate-600">RAKSHA AI // STARTUP SEQUENCE</div>
    <button onClick={onDone} className="absolute bottom-6 right-6 z-10 rounded border border-slate-700 px-3 py-1.5 text-xs text-slate-500 hover:border-cyan2 hover:text-white">Skip intro</button>
    <AnimatePresence mode="wait">
      {step === 1 && <Fade k="flag"><div className="flex flex-col items-center"><Flag/><div className="-mt-2 text-5xl">भारत</div><div className="mt-1 tracking-[.6em] text-slate-300">INDIA</div><div className="mt-4 text-[10px] tracking-[.35em] text-slate-500">FLAG // IDENTITY // SERVICE</div></div></Fade>}
      {step === 2 && <Fade k="motto"><div className="text-3xl tracking-widest text-saffron">SEVA PARAMO DHARMA</div><div className="mt-2 text-slate-200">SERVICE BEFORE SELF</div><div className="mt-3 text-xs text-slate-500">A public-awareness introduction</div></Fade>}
      {step === 3 && <Fade k="brand"><h1 className="text-5xl font-bold tracking-widest md:text-7xl">RAKSHA <span className="text-cyan2">AI</span></h1><p className="mt-3 text-xs tracking-[.25em] text-slate-400 md:text-sm">INDIA'S DEFENCE &amp; NATIONAL SECURITY AI ASSISTANT</p><div className="mt-7 text-[10px] tracking-[.35em] text-cyan2"><span className="mr-2 inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-cyan2"/> KNOWLEDGE CORE ONLINE</div></Fade>}
      {step === 4 && <Fade k="services"><div className="w-[min(92vw,760px)]"><ActiveScene/><div className="mb-2 flex justify-center gap-2">{SERVICES.map((s, i) => <button key={s.name} onClick={() => setService(i)} className="rounded-full border px-3 py-1.5 text-[10px] tracking-widest transition" style={{ borderColor: i === service ? s.color : "#263449", color: i === service ? s.color : "#718096", background: i === service ? `${s.color}14` : "transparent" }}>{s.icon} {s.label}</button>)}</div><AnimatePresence mode="wait"><motion.div key={active.name} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: .35 }}><div className="text-2xl font-semibold tracking-widest md:text-4xl" style={{ color: active.color }}>{active.name}</div><div className="mx-auto mt-2 max-w-xl text-sm text-slate-300">{active.copy}</div></motion.div></AnimatePresence><div className="mt-5 flex justify-center gap-2">{SERVICES.map((s, i) => <span key={s.name} className="h-1 rounded-full transition-all" style={{ width: i === service ? 42 : 14, background: i === service ? s.color : "#334155" }}/>)}</div></div></Fade>}
      {step === 5 && <Fade k="scope"><div className="tracking-[.35em] text-slate-300">LAND • SEA • AIR • CYBER • SPACE</div><div className="mt-3 text-sm text-slate-500">Ask questions. Learn safely. Stay informed.</div></Fade>}
    </AnimatePresence>
  </div>;
}
