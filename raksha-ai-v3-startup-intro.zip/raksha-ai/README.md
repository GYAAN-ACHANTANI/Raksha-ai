# RAKSHA AI

RAKSHA AI is an independent educational project about India's defence, public safety and national security. It is not affiliated with, endorsed by or operated by the Government of India or any armed service.

## Run locally

```bash
# terminal 1
cd backend
npm install
cp .env.example .env
npm run dev

# terminal 2
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`.

The frontend streams replies from `/api/chat/stream` and shows a live connection indicator. The backend uses the built-in contextual knowledge engine by default. To enable a compatible Anthropic model, set `AI_API_KEY` and optionally `AI_MODEL` in `backend/.env`; the built-in engine remains the fallback if the provider is unavailable.

## Safety behavior

Both the browser and backend apply a safety screen. RAKSHA AI does not provide operational, classified or harmful details such as current deployments, exact locations, routes, schedules, vulnerabilities, evasion instructions, weapon construction or attack planning. It redirects those requests toward public, high-level explanations.

## Highlights

- Real-time word-by-word streaming responses
- Context-aware follow-up handling and varied built-in answers
- Health monitoring in the chat header
- Animated waving flag and rotating LAND / SEA / AIR intro sequence
- Voice input, text-to-speech, regeneration and local conversation history
